package com.example.login.ui.theme

import androidx.compose.ui.graphics.Color
val Purple80 = Color(0xFF1D4460)
val PurpleGrey80 = Color(0xFFE0FDFF)
val Pink80 = Color(0xFF7AC2D5)

val Purple40 = Color(0xFF1D4460)
val PurpleGrey40 = Color(0xFFE0FDFF)
val Pink40 = Color(0xFF7AC2D5)