package com.example.login.viewModel

//class SignUpViewModel(private val repository: UserRepository) : ViewModel() {
//    fun signUp(username: String, email: String, password: String) {
//        // Add logic for sign-up, such as validating inputs and saving user data
//        val newUser = User(username, email, password)
//        repository.signUp(newUser)
//    }
//}
